# ie10-viewport-bug-workaround

This is the official workaround of the viewport bug of IE 10.0 for the
bootstrap 3.

See the Getting Started docs for more information:

http://getbootstrap.com/getting-started/#support-ie10-width
